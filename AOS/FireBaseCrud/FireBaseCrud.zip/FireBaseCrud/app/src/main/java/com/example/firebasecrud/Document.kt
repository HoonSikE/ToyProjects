package com.example.firebasecrud

data class Document(var title: String ?= null, val desc: String ?= null)

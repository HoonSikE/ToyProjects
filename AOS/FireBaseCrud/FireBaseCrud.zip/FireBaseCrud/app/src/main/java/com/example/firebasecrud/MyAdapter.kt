package com.example.firebasecrud

import android.view.View
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView

//class MyAdapter(private  val userList : ArrayList<Document>) : RecyclerView.Adapter<MyAdapter.MyViewHolder>() {
//
//    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int) : MyAdapter.MyViewHolder{
//
//    }
//
//    override fun onBindViewHolder(holder: MyAdapter.MyViewHolder, position: Int) {
//
//    }
//
//    override fun getItemCount(): Int {
//
//    }
//
//    public class MyViewHolder(itemView : View) : RecyclerView.ViewHolder(itemView){
//
//    }
//}

class MyAdapter : RecyclerView.Adapter<MyAdapter.MyViewHolder>() {

}